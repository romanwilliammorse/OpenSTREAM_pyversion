classdef (HandleCompatible) Input < dynamicprops & matlab.mixin.Copyable
    %INPUT Abstract superclass for input-handling classes
    %
    % Provides core functionality for reading, validating, and managing structured input data.
    % Supports dynamic property creation, default value handling, and solver-dependent customization.

    properties (SetAccess=protected)

        extra       = struct.empty()                             % Stores unused input entries for reference or debugging
        warnings    = struct.empty()                             % Stores warning messages generated during input parsing

    end

    methods

        function obj = Input(inputFilePath, key, val)
            %INPUT Constructor for Input class
            %
            % Parses input file and optionally filters entries by key-value pair.
            % Adds dynamic property 'inputStruct' to hold parsed data.
            %
            % Inputs:
            %
            % - inputFilePath — Path to input file (string)
            % - key           — Field name to filter by (optional)
            % - val           — Value to match for filtering (optional)

            arguments
                inputFilePath {mustBeText}                                  = ""
                key {mustBeText}                                            = ""
                val {mustBeA(val,["string","char","double"])}               = ""
            end

            % Return if empty inputFilePath
            if strlength(inputFilePath) == 0
                return
            end

            % Add temporary property inputStruct
            obj.addprop('inputStruct');

            % Parse and store the input file
            obj.inputStruct = obj.readInputFile(inputFilePath);

            %

            % limit input struct to entry specified by {key, val} pair
            if strlength(key) > 1

                % Find 1st matching entry with key having val
                if isnumeric(val)
                    entryIdx = find([obj.inputStruct.(key)] == val, 1);
                else
                    entryIdx = find(string({obj.inputStruct.(key)}) == val, 1);
                end

                % Throw error if none was found
                if isempty(entryIdx)
                    throw( ...
                        MException( ...
                        sprintf('OpenSTREAM:INPUT:entryNotFoundError'), ...
                        'Entry with key %s=%s was not found', key, num2str(val)) ...
                        );
                else
                    obj.inputStruct = obj.inputStruct(entryIdx);
                end

            end
        end

        function [isSpecifiedEntry, defaultUsed, defaultValue] = validateInputEntry(obj, objPropname, opts)
            % VALIDATEINPUTENTRY Validates whether a property entry is specified or defaulted
            %
            % Throws error if required entry is missing or empty
            % Returns flags and default value if applicable

            arguments
                obj
                objPropname
                opts.id = ''
            end

            % Warning setup
            previousWarnStruct = warning('query');
            warning('off','backtrace')
            objClassName = strrep(upper(class(obj)),'.','_');

            % Default false isValidEntry and defaultUsed
            isSpecifiedEntry = false;
            defaultUsed = false;
            defaultValue = [];

            % List of properties set in inputStruct
            inputStructFieldnames = fieldnames(obj.inputStruct);

            % objProp is a required property if it doesn't have a default
            % value, or if default value is empty
            propProps = findprop(obj,objPropname);
            propIsRequired = ~propProps.HasDefault || isempty(propProps.DefaultValue);

            % Find propname in inputStructFieldnames
            if find(strcmp(inputStructFieldnames, objPropname))

                % Variable is specified
                isSpecifiedEntry = true;

                % assign field entry as inputField
                inputField = obj.inputStruct.(objPropname);

                % Is inputField value empty
                inputFieldIsEmpty = isempty(inputField) || (isstring(inputField) && strlength(inputField)==0);

                % Check requirements
                if propIsRequired && inputFieldIsEmpty
                    % Throw exception if property is required, yet a
                    % value was not specified
                    throwAsCaller( ...
                        MException( ...
                        sprintf('OpenSTREAM:%s:missingRequiredValueError',objClassName), ...
                        'Required entry with key %s for %s is empty', objPropname, opts.id) ...
                        );
                elseif ~propIsRequired && inputFieldIsEmpty
                    % Provide warning if property is optional and a
                    % value was not specified. Use default instead.
                    % warning('%s: Value for entry %s was not set. Default value used: %s', ...
                    %     objClassName, objPropname, Inputs.Input.defaultValueString(propProps.DefaultValue));
                    defaultUsed = true;
                    defaultValue = propProps.DefaultValue;
                else
                    % Assign specified non-empty value to property
                    % Let MATLAB throw errors from parameter validation
                end

                % Special case: logical value specified as strings "true"
                % or "false.
                if islogical(obj.(objPropname)) && isStringScalar(inputField)
                    % Logicals can be saves/specified as string "true", 
                    % "false", which are not convertible to logicals. If
                    % so, update the inputStruct entry.
                    switch lower(obj.inputStruct.(objPropname))
                        case "false"
                            obj.inputStruct.(objPropname) = false;
                        case "true"
                            obj.inputStruct.(objPropname) = true;
                        otherwise
                            error(sprintf('OpenSTREAM:%s:invalidLogicalValueUsedWarning',objClassName), ...
                            'String %s given for logical property %s. Aborting.\n', ...
                            inputField, ...
                            objPropname);
                    end
                end
            else
                if propIsRequired
                    % A required property was not specified
                    throwAsCaller( ...
                        MException( ...
                        sprintf('OpenSTREAM:%s:missingRequiredValueError',objClassName), ...
                        'Required entry with key %s for %s is missing', objPropname, opts.id) ...
                        );
                else
                    % An optional property was not specified

                    % warning('%s: Value for optional property %s was not set. Default value used: %s', ...
                    %     objClassName, objPropname, Inputs.Input.defaultValueString(propProps.DefaultValue));
                    defaultUsed = true;
                    defaultValue = propProps.DefaultValue;
                end
            end

            % Reset warning state
            warning(previousWarnStruct);
        end

        function [objPropNames_filtered, objPropDefaultValues_filtered, nameValPair] = ...
                        listInputProperties(obj, opts)
            %LISTINPUTPROPERTIES Returns list of protected property names for the object
            %
            % Optionally excludes specified properties

            arguments
                obj
                opts.exclude = {}   % Cell array of properties to exclude from the list
            end
            
            % Get full list of properties
            objProps = metaclass(obj).PropertyList;
            % Get full list of property names
            objPropNames = string({objProps.Name}.');

            % Filter down to those:
            %   - with a specific class with set access
            %   - without the name of 
            %       - SOLVERDEPENDENTPROPS
            %       - extra
            %       - warnings
            objPropNames_filtered = objPropNames( ...
                cellfun(@(setaccess) isa(setaccess, 'meta.class'), [objProps.SetAccess]) ...
                & ~strcmp(string({objProps.Name}),'SOLVERDEPENDENTPROPS')...
                & ~strcmp(string({objProps.Name}),'extra')...
                & ~strcmp(string({objProps.Name}),'warnings'));

            % Exclude properties specified in opts.exclude
            for idx = 1:length(opts.exclude)
                objPropNames_filtered = objPropNames_filtered( ...
                    ~strcmpi(objPropNames_filtered,opts.exclude{idx}));
            end

            % Retrieve default values if nargout > 1
            if nargout < 2
                return
            end
            num_props = numel(objPropNames_filtered);
            objPropDefaultValues_filtered = cell(num_props,1);
            for idx = 1:num_props
                
                % Find property in objPropNames
                propIdx = find(objPropNames == objPropNames_filtered{idx});

                % Store DefaultValue for those properties that HasDefault
                if objProps(propIdx).HasDefault
                    % Add default value to objPropDefaultValues
                    objPropDefaultValues_filtered{idx} = objProps(propIdx).DefaultValue;
                else
                    % Try to create empty value for the property class type
                    try
                        defVal = eval(string(objProps(propIdx).Validation.Class.Name) + ".empty");
                    catch
                        % Silently ignore any resulting error.
                        % There are potentially just too many class types
                        % to effectively handle.
                        defVal = NaN;
                    end
                    objPropDefaultValues_filtered{idx} = defVal;
                end
            end

            % Create name-value pair struct if nargout > 2
            if nargout < 3
                return
            end
            nameValPair = cell2struct(objPropDefaultValues_filtered, objPropNames_filtered);
               
        end

        function [varargout] = defaultValueUsedReport(obj, propNames, propValues)
            %DEFAULTVALUEUSEDREPORT Generates report of properties for which default values were used
            %
            % Can print or return formatted string array

            arguments
                obj
                propNames   string
                propValues  cell
            end

            % TODO: Check propNames and propValues size matches

            % Init. string array
            rep = "";

            % Title line
            rep(end+1) = sprintf("Default values were used for the following variables in %s:", upper(class(obj)));

            % Max propname length
            propName_max = max(arrayfun(@(n) strlength(n),propNames));

            % For each propName, add entry to rep
            for i = 1:length(propNames)

                % Get propname, propvalue
                propName = propNames(i);
                propValue = propValues{i};

                % Identify propValue type format
                if isstring(propValue) || ischar(propValue)
                    %propValue = propValue;
                elseif isnumeric(propValue)
                    % Check if is scalar
                    if isscalar(propValue)
                        addBrackets = false;
                    else
                        addBrackets = true;
                    end
                    % Convert to string and add brackets
                    % NOTE: 2D+ arrays will be reshaped...
                    propValue = sprintf('%f ', propValue);
                    if addBrackets
                        propValue = sprintf('[%s]', propValue);
                    end
                elseif isa(propValue, "function_handle")
                    % Convert to string
                    propValue = sprintf('%s ', func2str(propValue));

                else
                    % TODO: Throw error or handle it somehow
                end

                % Create string
                rep(end+1) = sprintf(sprintf('%%-%ds: %%s ',propName_max+2), propName, propValue);

            end


            if nargout == 1
                % return if nargout == 1
                varargout(1) = {rep};
            elseif nargout == 0
                % print if no outputs requested
                fprintf('%s\n', rep)
            else
                % TODO: Throw error for requesting too many outputs
            end

        end

        function out = applySolverDependentProperties(obj, solverName)
            %APPLYSOLVERDEPENDENTPROPERTIES Applies solver-specific property values based on dependency flags
            %
            % Returns a copy of the object with updated properties

            out = copy(obj);

            % Convert solvername to upper
            solverName = upper(solverName);

            % Check if SOLVERDEPENDENTPROPS is a property
            %   simply exit if not
            if ~isprop(out, 'SOLVERDEPENDENTPROPS')
                return;
            end

            % Iterate through each field in SOLVERDEPENDENTPROPS
            depPropNames = fields(out.SOLVERDEPENDENTPROPS);
            for i = length(depPropNames)
                % Name of property
                depPropName = depPropNames{i};

                % Details of the solver dependency
                depProp = out.SOLVERDEPENDENTPROPS.(depPropName);

                % Retrieve flag that shows property is solver dependent
                dep_flag = depProp.DEP_FLAG;

                % See if property is set to be dependent
                if out.(depPropName) == dep_flag

                    % Find solver in depProp details
                    if isfield(depProp, solverName)
                        % Identify detail type
                        if isenum(depProp.(solverName)) || out.(depPropName)
                            % Simply replace an enum or numeric value
                            out.(depPropName) = depProp.(solverName);
                        elseif isstruct(depProp.(solverName))
                            % Expect a field called value
                            out.(depPropName) = depProp.(solverName).value;
                            % TODO: Handle further instructions. For
                            % example, models that require different
                            % coefficients can be specified and applied
                            % here. This case is not tested.
                        end
                        % Apply default if
                    elseif isfield(depProp, 'DEFAULT')
                        out.(depPropName) = depProp.DEFAULT;
                    end
                end
            end
        end

    end

    methods(Static, Access=protected)

        function inputStruct = readInputFile(filePath)
            %READINPUTFILE Reads and parses input file into structured format
            %
            % Supports .json and .inp formats
            % Throws error for unsupported formats or read failures

            arguments
                filePath {mustBeFile}
            end

            % Try to open and read the file
            try
                fileContent = readlines(filePath);
                [~,fileName,fileExt] = fileparts(filePath);
            catch ME
                % TODO: decide whether to just set the output to -1 or
                % throw an error. The error message needs improvement.
                % inputStruct = -1;
                ME_local = MException( ...
                    sprintf('OpenSTREAM:INPUT:openFileError'), ...
                    'Reading file at %s resulted in an error.', filePath ...
                    );
                rethrow(addCause(ME, ME_local));
            end

            % Choose parser depending on file extenstion
            switch lower(fileExt)
                case '.json'
                    % Read the json file
                    inputStructJson = jsondecode(strjoin(fileContent));

                    % jsondecode outputs a cell array of structs when extra
                    % or missing fields are present
                    if iscell(inputStructJson)

                        % Compile the full array of fieldnames
                        fullFieldnames = {};

                        %
                        for i = 1:length(inputStructJson)
                            fullFieldnames = unique([fullFieldnames; fieldnames(inputStructJson{i})]);
                        end

                        % Convert each cell to a struct with the
                        % fullFieldNames
                        inputStruct(length(inputStructJson),1) = ...
                            cell2struct(cell(length(fullFieldnames),1),fullFieldnames,1);
                        for i = 1:length(inputStructJson)
                            for j = 1:length(fullFieldnames)
                                fullFieldname = fullFieldnames{j};
                                if isfield(inputStructJson{i},fullFieldname)
                                    inputStruct(i).(fullFieldname) = inputStructJson{i}.(fullFieldname);
                                end
                            end
                        end

                    else
                        inputStruct = inputStructJson;
                    end

                case '.inp'

                    % Regex expression for parsing the input file.
                    entryExpr = {};
                    %   Capture the "END" tag
                    entryExpr{1} = '(?<PARAMETER>(end|END))';
                    %   Capture comments, indicated by '#' symbol
                    entryExpr{2} = '(?<PARAMETER>(#|\/\/|%)).*';
                    %   Capture PARAMETER ! DESCRIPTION > VALUE
                    entryExpr{3} = '(?<PARAMETER>[\w]+)?\s*\!\s*(?<DESC>.*?)>\s*"*(?<VALUE>[@><=&|()\/\*\[\],\w\s\+\-\.]*)?"*';
                    %   Join parts together and remove spaces (use \s instead).
                    entryExpr = strrep(strjoin(entryExpr,'|'),' ','');

                    % Parse file using regex
                    fileStruct = regexpi(fileContent, sprintf('%s',entryExpr),"names");

                    % Initalize output struct
                    inputStruct = struct();
                    inputStructEntriesCount = 0;
                    inputStructEntryFields = string().empty();

                    % Loops through each row of fileStruct
                    for fileLineIdx = 1:length(fileStruct)

                        % Index into fileStruct
                        fileRow = fileStruct{fileLineIdx};

                        % Skip if fileRow is empty
                        if isempty(fileRow)
                            continue;
                        end

                        % Process fileRow depending on PARAMETER value
                        switch fileRow.PARAMETER
                            case "END"
                                % Increment inputStructEntries
                                inputStructEntriesCount = inputStructEntriesCount + 1;
                                % Reset EntryFields
                                inputStructEntryFields = inputStructEntryFields.empty();

                            case {"COMMENT", '#' ,'//', '%'}
                                % Ignore comments for now

                            otherwise
                                % if parameter was already specified, throw
                                % error
                                if ~isempty(inputStructEntryFields) && ismember(fileRow.PARAMETER,inputStructEntryFields)
                                    throw( ...
                                        MException( ...
                                        sprintf('OpenSTREAM:INPUT:duplicateEntryError'), ...
                                        'A duplicate of parameter %s was detected on line %d in file %s%s', ...
                                        fileRow.PARAMETER, fileLineIdx, fileName, fileExt) ...
                                        );
                                else
                                    inputStructEntryFields(end+1) = fileRow.PARAMETER;
                                end
                                % Throw warning if field value is empty
                                valueToSave = '';
                                if strlength(fileRow.VALUE) == 0
                                    % TODO throw warning for empty field value
                                    valueToSave = '';
                                else
                                    % Look for numeric values
                                    numericValues = textscan(fileRow.VALUE, '%f');
                                    numericValues = numericValues{1};
                                    if isempty(numericValues)
                                        valueToSave = fileRow.VALUE;
                                    else
                                        valueToSave = numericValues;
                                    end
                                end
                                % Save entry values
                                inputStruct(inputStructEntriesCount+1).(fileRow.PARAMETER) = valueToSave;
                        end

                    end
                otherwise
                    % Unknown or unspecified file extensions are not
                    % supported.
                    throw( ...
                        MException( ...
                        sprintf('OpenSTREAM:INPUT:fileTypeError'), ...
                        'Input file with extension %s is not supported.', fileExt) ...
                        );
            end
        end

        function defVal = defaultValueString(defVal)
            %DEFAULTVALUESTRING Converts default value to string representation for reporting
            %   TODO: This may be be deprecated.

            if isnumeric(defVal)
                defVal = num2str(defVal);
            elseif islogical(defVal)
                defVal = string(defVal);
            end
        end

    end

    methods(Static)
        function writeInputFile(filePathName, fidMode, varargin)
            %WRITEINPUTFILE Writes input data to file in standard format
            %
            % Accepts name-value pairs and optional file mode

            if mod(length(varargin),2) == 1
                error('An even number of inputs after filePath is required.');
            end

            % Gather calling class property names
            callStack = dbstack();
            [~,callClass] = fileparts(callStack(2).file);
            callClass = ['Inputs.' callClass];
            callClass = eval(['?' callClass]);
            descriptionDict = containers.Map( ...
                {callClass.PropertyList.Name}, ...
                {callClass.PropertyList.Description});

            % Create file to write
            fid = fopen(filePathName,fidMode);
            if fid == -1
                error('An error occurred while creating %s', filePathName);
            end

            for idx = 1:length(varargin)/2

                % Odd idx refer to the names
                varIdx = 2*idx-1;

                % Force name to be upper case
                varName = upper(string(varargin{varIdx}));

                % Force value to be a string
                varValue = varargin{varIdx+1};
                if isnumeric(varValue)
                    varValue = num2str(reshape(varValue,1,[]),'%.11f ');
                elseif islogical(varValue)
                    varValue = string(varValue);
                elseif isa(varValue, 'function_handle')
                    varValue = func2str(varValue);
                elseif ((isStringScalar(varValue) || ischar(varValue)) && startsWith(strtrim(varValue), '@'))
                    % Don't modify value
                else
                    varValue = upper(varValue);
                end

                % Determine action given varName
                switch varName

                    % NOTE: Other options can be specified here

                    otherwise

                        % Find varName in descriptionDict
                        if descriptionDict.isKey(varName)
                            description = descriptionDict(varName);
                        else
                            description = '';
                        end

                        % Print line in file
                        fprintf(fid, '%-11s! %-63s> %s\n', varName, description, varValue);
                end
            end

            % Print
            fprintf(fid,'END\n\n');

            % Close file
            fclose(fid);
        end

        function validateFunctionHandleInput(handleString)
            %VALIDATEFUNCTIONHANDLEINPUT Validates safety of function handle string
            %
            % Throws error if restricted keywords are detected

            arguments
                handleString    {mustBeTextScalar}
            end

            restrictedKeywords = ["eval", "feval", "system", "fopen", "delete", "!", ...
                "load", "save", "assignin", "clear", "global", "import", ...
                "java", "py\.", "web", "dir", "cd", "run", "builtin", ...
                "uigetfile", "input", "persistent", "classdef", "meta\."];

            for restrictedKeyword = restrictedKeywords
                if ~isempty(regexp(handleString, restrictedKeyword, 'once', 'ignorecase'))
                    error("Unsafe content detected: '%s' in function handle: %s", restrictedKeyword, handleString);
                end
            end
        end

        function jsonText = convert2JSON(inputFilePath)
            %CONVERT2JSON Converts input file contents to JSON-formatted string

            % Read inputFilePath
            inputStruct = Inputs.Input.readInputFile(inputFilePath);

            % convert inputObj.inputStruct to json format
            jsonText = jsonencode(inputStruct,"PrettyPrint",true);
        end

    end

end
